from django.db import models

class Produto(models.Model):
    #nome, marca, pre ̧co, imagem, descrição
    nome = models.CharField(max_length=100)
    marca = models.CharField(max_length=50)
    preco = models.FloatField()
    descricao = models.TextField()

    
